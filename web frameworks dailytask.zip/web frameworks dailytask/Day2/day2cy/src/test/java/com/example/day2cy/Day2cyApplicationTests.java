package com.example.day2cy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2cyApplicationTests {

	@Test
	void contextLoads() {
	}

}
